<html>
<head>
    <title>CLI Tool</title>
</head>
    <h2>Welcome to CLI Tool!</h2>
	<body>
        <form action="src\CLI.php" method="post">
            <label for="str">Enter String:</label><br>
            <input type="text" id="str" name="str" autocomplete="off" required><br><br>
            <button type="submit" name="upper">Upper String</button>
            <button type="submit" name="alternate">Alternate String</button>
            <button type="submit" name="createFile">Create CSV File</button>
        </form>
	</body>
</html>
