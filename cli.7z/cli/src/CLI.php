<?php

namespace App;

include ("CreateFile.php");
include("ConvertString.php");

/**
 * CLI Tool provides all public function like upper, alternate, create file etc
 * 
 * @package    src
 * @subpackage CLI
 * @author     obaidul haque
*/
class CLI
{
    /**
    * Hold the value of data source when called setDataSource.
    *
    * @var string
    */
    private $dataSource;
    //public $msg;
    
    /**
     * setDataSource
     * keep string value as a data source
     *
     * @return boolean
    */
    public function setDataSource($str)
    {
        if (!isset($str) || trim($str) === '')
        {
            echo "Can not empty or white space";
            return false;
        }

        if (!is_string($str))
        {
            echo "Invaid data."; 
            return false;
        }

        $this->dataSource = $str;
        return true;
    }

    /**
     * createCSVFile
     * create a csv file with provided string
     *
     * @print created file
    */
    public function createCSVFile()
    {
        $newFile = new \App\CreateCSVFile($this->dataSource);
        $newFile->createFile();
        echo ($newFile->createFile() == true)? "CSV created!" : "CSV can not created!";
    }

    /**
     * stringUpperCase
     * convert a string to an upper string
     *
     * @print upper string
    */
    public function stringUpperCase()
    {
        $obj = new \App\ConvertString($this->dataSource);
        echo $obj->getUpperCase();
    }

    /**
     * stringAlternateCase
     * convert a string to an alternate string
     *
     * @print alternate string
    */
    public function stringAlternateCase()
    {
        $obj = new \App\ConvertString($this->dataSource);
        echo $obj->getAlternateCase();
    }
}


/**
* Handling client's post request from index.php
* 
* @param user provided string 
* @print output
*/
if(isset($_POST['str']))
{
    $obj = new CLI();

    $str = $_POST['str'];
    $obj->setDataSource($str);

    if(isset($_POST['upper'])) $obj->stringUpperCase();
    else if(isset($_POST['alternate'])) $obj->stringAlternateCase();
    else if(isset($_POST['createFile'])) $obj->createCSVFile();
}