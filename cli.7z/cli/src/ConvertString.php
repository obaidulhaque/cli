<?php

namespace App;


interface iConvertString
{
	public function getUpperCase() : string;
	public function getAlternateCase() : string;
}


/**
 * ConvertString convert a string to a new form like upper, lower, alternate etc.
 * 
 * @package    src
 * @subpackage CLI
 * @author     obaidul haque
*/
class ConvertString implements iConvertString
{
	/**
    * Hold the value of data source when create a obj.
    *
    * @var string
    */
	private $str;
	
	/**
    * Class constructor.
    * @param string
    */
    public function __construct($_str)
	{
		$this->str = $_str;
	}

	/**
     * getUpperCase
     * convert a string to an upper string
     *
     * @return string
    */
    public function getUpperCase() : string
	{
		$newStr = strtoupper($this->str);
		return $newStr;
	}
	
	/**
     * getAlternateCase
     * convert a string to an alternate string
     *
     * @return string
    */
    public function getAlternateCase() : string
	{
		$length = strlen($this->str);
		$newStr = $this->str;
		for ($i = 1 ; $i < $length ; $i = $i + 2) $newStr[$i] = strtoupper($newStr[$i]);
		return $newStr;
	}	
    
}