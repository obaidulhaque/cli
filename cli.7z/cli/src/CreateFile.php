<?php

namespace App;

abstract class BaseFileCreation
{
    protected $dataSource;
    protected $content_type = "Content-type: text/";
    protected $content_disposition = "Content-Disposition: attachment; filename=";
    protected $content_output = "php://output";

    public function __construct($data)
	{
		$this->dataSource = $data;
	}
    
    protected function isFileExist($fileName)
    {

       $filePath = 'C:\Users\user\Downloads';
       $file = $filePath.'\\'.$fileName;
       
       if (file_exists($file) && filesize($file) > 0) return true;

       return false;
    }

    abstract public function createFile();
    abstract protected function setHeader();
    abstract protected function setFileType();
}

abstract class FileType
{
    const CSV = 'csv';
    const XML = 'xml';
    const JSON = 'json';
}

class CreateCSVFile extends BaseFileCreation
{
    private  $fileName;

    protected function setHeader()
    {
        header($this->content_type.FileType::CSV);
        header($this->content_disposition."$this->fileName");
    }

    protected function setFileType()
    {
        $this->fileName = 'characterData.'.FileType::CSV;
    }
    
    public function createFile()
    {
        $arr = str_split($this->dataSource);        
        $this->setFileType();
        
        if($this->isFileExist($this->fileName))
        {
            return false;
        } 

        $this->setHeader();

        $output = fopen($this->content_output, "w");
        $header = array_values($arr);

        if (fputcsv($output, $header) == false)
        {
            fclose($output);
            return false;
        } 

        fclose($output);
        return true;
    }
}