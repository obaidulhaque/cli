<?php

use PHPUnit\Framework\TestCase;

class CLITest extends TestCase
{
    public function testSetDataSource()
    {
        $obj = new \App\CLI();
        $expected = true; 
        $actual = $obj->setDataSource("hello world");

        $this->assertEquals( 
            $expected, 
            $actual, 
            "actual value is not equals to expected"
        ); 
    }

    public function testSetDataSourceAcceptOnlyString()
    {
        $obj = new \App\CLI();
        $expected = false; 
        $actual = $obj->setDataSource(123);

        $this->assertEquals( 
            $expected, 
            $actual, 
            "Invalid Data!"
        ); 
    }

    public function teststringUpperCase()
    {
        $obj = new \App\CLI();
        $obj->setDataSource("hello");

        $expected = "HELLo"; 

        ob_start();
        $obj->stringUpperCase();
        $actual = ob_get_contents();
        ob_end_clean();

        $this->assertEquals( 
            $expected, 
            $actual, 
            "Does not match"
        ); 
    }

    public function teststringAlternateCase()
    {
        $obj = new \App\CLI();
        $obj->setDataSource("hello world");

        $expected = "hElLo wOrLd"; 

        ob_start();
        $obj->stringAlternateCase();
        $actual = ob_get_contents();
        ob_end_clean();

        $this->assertEquals( 
            $expected, 
            $actual, 
            "Does not match"
        ); 
    }

    public function testCreateCSVFile()
    {
        $obj = new \App\CLI();
        $obj->setDataSource("hello world");

        $expected = "CSV created!";

        ob_start();
        $obj->createCSVFile();
        $actual = ob_get_contents();
        ob_end_clean();

        $this->assertEquals( 
            $expected, 
            $actual, 
            "Does not match"
        ); 
    }
}