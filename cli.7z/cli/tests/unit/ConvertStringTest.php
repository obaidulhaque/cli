<?php

use PHPUnit\Framework\TestCase;

class ConvertStringTest extends TestCase
{
    public function testGetUpperCase()
    {
        $obj = new \App\ConvertString("hello");
        $expected = "HELLO"; 
        $actual = $obj->getUpperCase();

        $this->assertEquals( 
            $expected, 
            $actual, 
            "Does not match"
        ); 
    }

    public function testGetAlternateCase()
    {
        $obj = new \App\ConvertString("hello world");
        $expected = "hElLo wOrLd";  
        $actual = $obj->getAlternateCase();

        $this->assertEquals( 
            $expected, 
            $actual, 
            "Does not match"
        ); 
    }

    public function test_instanceOf()
    {
        $obj = new \App\ConvertString("hello world");
        $this->assertInstanceOf(ConvertString::class, $obj);
    }

}