<?php

use PHPUnit\Framework\TestCase;

class CreateFileTest extends TestCase
{
    public function testCreateFile()
    {
        $obj = new \App\CreateCSVFile("hello world");
        $filePath = 'C:\Users\user\Downloads';
        $fileName = 'characterData.csv';
        $file = $filePath.'\\'.$fileName;

        $expected = true; 
        $actual = $obj->createFile();

        $this->assertEquals( 
            $expected, 
            $actual, 
            "actual value is not equals to expected"
        ); 
    }

    public function testFileReadable()
    {
        $filePath = 'C:\Users\user\Downloads';
        $fileName = 'characterData.csv';
        $this->assertFileIsReadable($filePath.'\\'.$fileName);
    }

    public function testFileWriteable()
    {
        $filePath = 'C:\Users\user\Downloads';
        $fileName = 'characterData.csv';
        $this->assertIsWritable($filePath.'\\'.$fileName);
    }
}